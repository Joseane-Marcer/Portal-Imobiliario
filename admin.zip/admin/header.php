<!doctype html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Portal MEUIMÓVEL | Painel de controle</title>
<link href="../painel_style.css" rel="stylesheet" type="text/css" />
<?php include"sistema/scripts.php";?>
</head>

<body>

<div id="box">
  
  <div id="header">
  
    <div id="header_logo">
      <img src="../images/logo_meuImoveu2.png"alt="Painel de controle" />
      
      
      
    </div><!--header logo-->
    
      <div id="header_banner">
         <!--<img src="images/exemplo_banner.jpg" alt="" />-->
         
<script type="text/javascript"><!--
google_ad_client = "pub-2379415706170373";
/* 728x90, created 6/22/11 */
google_ad_slot = "1239685701";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script><br />
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script> 
  
         
      </div><!--header banner-->
      
   </div><!--header-->