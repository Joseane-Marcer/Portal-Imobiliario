       <div id="footer">
       © MEUIMÓVEL Todos os Direitos Reservados<br />
       Fone (xx11) 3333-3333 | Email: suporte@meuimovel.com.br
       </div><!--footer-->


</div><!--box-->


</body>
</html>