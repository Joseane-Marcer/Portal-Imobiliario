<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Portal MEUIMÓVEL | Painel de Administração</title>
<link href="login_style.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div id="login">
  <img src="../images/teste.fw.png"  alt="" />
  <form name="login_painel" action="" method="post">
    
   <span class="envie">Para receber os dados de acesso, informe abaixo seu e-mail de login</span>
   
    <label><span>E-mail: </span><input type="text" name="email" /></label>
    <p><a href="index.php">[ Voltar e logar ]</a><p>
    <input type="submit" name="logar" value="Logar" class="btn" />
  </form>

<div class="alertas">
<strong style="color:#063;">[&loz;]</strong> Enviamos seus dados de acesso para seu e-mail!
</div>


</div><!--login-->

</body>
</html>