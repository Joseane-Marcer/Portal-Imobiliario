<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery_validate.js"></script>
<script type="text/javascript" src="js/validate_func.js"></script>