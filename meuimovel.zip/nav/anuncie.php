<div id="pagina">

   <h1>Anuncie</h1>
   
     <div class="anuncie">
     <h2>Cadastre-se e anuncie:</h2>

    <p>O Sistema de anúncios do portal MEUIMÓVEL e totalmente automatizado. Você se cadastra e terá acesso a um painel de controle como área de membros onde você poderá!</p>

     <p>
     &raquo; Cadastrar imóveis!<br />
     &raquo; Editar seus Anúncios!<br />
     &raquo; Responder mensagens!<br />
     &raquo; Conferir estatísticas!<br />
     &raquo; Efetuar pagamentos!<br />
     &raquo; Alterar seus dados!<br />
     &raquo; e muito mais....</p>

     <p>Cadastra-se agora e comece a anunciar seu imóvel na melhor opção de anúncios imobiliários da web!</p>

     <p><strong>Duvidas? <a href="index.php?pg=contato">Clique aqui!</a></strong></p>
     </div><!--fecha anuncies-->
   
     <form name="cadastra_cliente" id="cadastra_cliente" method="post" action="index.php?pg=anuncie_ok" enctype="multipart/form-data">
       
       <fieldset><legend>Cadastre-se e Anúncie</legend> 
        
        <label>
          <span>Nome completo:</span>
          <input type="text" name="nome" />
        </label>
        
        <label>
          <span>E-mail:</span>
          <input type="text" name="email" />
        </label>
        
        <label>
          <span>Senha:</span>
          <input type="password" name="senha" />
        </label>
        
        <label>
          <span>Telefone:</span>
          <input type="text" name="telefone" />
        </label>
        
           
          <input type="submit" name="cadastrar_cliente" id="cadastrar_cliente" value="Cadastrar" class="btn" />
        
        
       </fieldset>
            
     </form>

</div><!--fecha pagina-->    
     
