<div id="pagina">
   
  <h1>Categoria</h1>
   <table width="100%" border="0" cellpadding="3" cellspacing="2" bordercolor="#666666";>
     <tr style="color:#005789; font-variant:small-caps; font:14px 'Trebuchet MS', Arial, Helvetica, sans-serif;">
       <td height="30" align="center" bgcolor="#E0E0E0"><strong>Ilustração:</strong></td>
       <td align="center" bgcolor="#E0E0E0"><strong>Operação:</strong></td>
       <td align="center" bgcolor="#E0E0E0"><strong>Dormitórios:</strong></td>
       <td align="center" bgcolor="#E0E0E0"><strong>Data do Anúncio:</strong></td>
       <td align="center" bgcolor="#E0E0E0"><strong>Acessar:</strong></td>
     </tr>
       <?php get_categoria();?>
   </table>
   
   <div class="paginator">
   <a href="#">Primeira </a> <a href="#">1</a> <a href="#">2</a> <a href="#">3</a> <a href="#">4</a>
   <a href="#">5</a> <a href="#">6</a> <a href="#">7</a> <a href="#">8</a> <a href="#">9</a> 
   <a href="#">10</a> <a href="#">Última</a>
   
   </div><!--paginator-->
   

</div><!--fecha pagina-->    
