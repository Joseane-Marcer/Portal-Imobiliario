       <div id="imoveis_home_lista">
       
         <ul>
           <?php footerPosts();?>    
         </ul>
       
       </div><!--fecha home lista-->


<div id="clear"></div>

</div><!---fecha div box-->

  <div id="footer">
  
    <div id="footer_bg">
    
      <div class="txt">
      © MEUIMÓVEL Todos os Direitos Reservados
      <span>Anúncie seu imóvel através de nosso portal</span>
      </div><!-- fecha class txt-->
      
      <div class="img">
      <a href="#"><img src="images/teste.fw.png" alt="" title="" border="0" /></a>
      </div><!--fecha class img-->
    
    </div><!--footer bg-->
  
  </div><!--fecha footer-->

<div style="display:none;">
<img src="images/teste.fw.png" alt="" />
</div><!-- CARREGANDO IMAGENS DE EFEITOS -->

</body>
</html>