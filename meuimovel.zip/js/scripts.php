<!-- JS -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery_validate.js"></script>
<script type="text/javascript" src="js/validate_func.js"></script>
<script type="text/javascript" src="js/filtro.js"></script>
<script type="text/javascript" src="js/shadowbox_js/shadowbox.js"></script>
<link rel="stylesheet" type="text/css" href="js/shadowbox_js/shadowbox.css">
<script type="text/javascript">
Shadowbox.init({
    language: 'pt',
    players:  ['img', 'html', 'iframe', 'qt', 'wmp', 'swf', 'flv'],
});
</script>
<!-- PHP -->